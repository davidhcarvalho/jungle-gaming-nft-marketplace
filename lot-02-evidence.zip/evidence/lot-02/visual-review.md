# Revisão visual — Lote 02

Data da inspeção: 2026-10-30. Referências abertas individualmente em resolução suficiente; comparadas com as capturas anteriores a esta rodada em `home-mobile-390-review.png`, `home-desktop-1440-review.png`, `detail-mobile-390-review.png` e `detail-desktop-1440-review.png`.

| Área | Diferença observada | Correção aplicada | Verificação pendente |
| --- | --- | --- | --- |
| Home mobile | Headline desktop longa quebrava em quatro linhas; descrição extensa tornava o hero mais alto e empurrava catálogo para baixo em relação ao frame móvel. | Copy mobile específica, curta, correspondente à composição “Seja dono da cultura digital” e descrição de uma linha curta; título reduzido para duas linhas. | Recapturar em 390×844 e 414×896 e confirmar quebra/altura. |
| Home desktop | Sidebar acabava nos filtros, mas o Figma mostra card “NFT em destaque / Oferta limitada” abaixo deles. | Adicionado card de destaque no sidebar desktop; oculto em layout móvel onde o frame não o mostra. | Recapturar 1440 e confirmar dimensões/posição. |
| Detalhe mobile | Botões de voltar/favoritar estavam ancorados ao painel de informações por `top: -374px`, vulnerável à altura do artwork; imagem começava no topo, enquanto o Figma reserva uma faixa superior aos controles. | Ações movidas para a galeria, `top: 14px`; galeria reserva `66px` antes do artwork. | Recapturar 390/414 e validar sobreposição e interação. |
| Detalhe mobile — edição esgotada | Mensagem de indisponibilidade estava só no resumo desktop, escondido em mobile. | Adicionado status visível na região sticky “Resumo da compra”. | Testar disponibilidade, acessibilidade e sobreposição em browser. |
| Capturas | Full-page mobile produzia imagem de milhares de pixels e posicionava o elemento fixo em local inadequado para comparação com frames de ~896 CSS px. | Captura mobile alterada para viewport; desktop permanece full-page para avaliar composição longa. | Gerar novas capturas e comparar após correções. |

## Diferenças conhecidas

- Os quatro retratos locais são substitutos provisórios e diferem dos assets NFT exibidos no Figma; assets de origem não vieram no pacote (ADR-004/Q2).
- A fonte Figma exata ainda não foi identificada (Q1); o fallback mono muda métricas e quebras tipográficas.
- As capturas na tabela são anteriores às correções. O sandbox impede iniciar Vite (`listen EPERM` em `127.0.0.1:4180`), portanto nenhuma correção visual foi aprovada por screenshot pós-mudança.
